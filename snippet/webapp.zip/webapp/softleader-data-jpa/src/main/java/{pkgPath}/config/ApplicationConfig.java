package {pkg}.config;

import org.springframework.context.annotation.*;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.orm.jpa.vendor.Database;
import tw.com.softleader.data.config.EnableCoreDataSource;
import tw.com.softleader.data.dao.GenericCrudDaoImpl;
import tw.com.softleader.data.entity.EntityPersistenceCallbackSupplier;
import tw.com.softleader.domain.annotatioin.EnableCoreDomain;
import tw.com.softleader.security.supplier.CurrentUsernameSupplier;

@EnableAspectJAutoProxy(proxyTargetClass = true, exposeProxy = true)
@ComponentScan(basePackages = "{pkg}.**.service")
@EnableJpaRepositories(
  basePackages = {"tw.com.softleader.data.**.dao", "{pkg}.**.dao"},
  repositoryBaseClass = GenericCrudDaoImpl.class
)
@EnableCoreDataSource(
  persistenceUnitName = "{pj}",
  database = Database.{database},
  idStrategies = {"{pkg}.**=AUTO", "tw.com.softleader.**=AUTO"},
  entityPackagesToScan = "{pkg}.**.entity",
  propertySources = "classpath:datasource.properties"
)
@EnableCoreDomain
@Configuration
public class ApplicationConfig {

  @Bean
  public CurrentUsernameSupplier currentUsernameSupplier() {
    CurrentUsernameSupplier supplier = new CurrentUsernameSupplier();
    // 跑排程, test, 或開 future 等都會沒有 authentication
    // 也可以選擇不設定預設值, 則遇到時就會丟出 IllegalStateException, 實作的程式就必須處理
    supplier.setDefaultIfAuthenticationNotFound("{pj}");
    return supplier;
  }

  @Bean
  @Primary
  public EntityPersistenceCallbackSupplier entityPersistenceCallbackSupplier() {
    return new EntityPersistenceCallbackSupplier(currentUsernameSupplier());
  }
}
