package {pkg}.demo.dao;

import tw.com.softleader.data.dao.GenericCrudCodeDao;
import {pkg}.demo.entity.Demo;

public interface DemoDao extends GenericCrudCodeDao<Demo, Long> {

}
