package {pkg}.config;

import org.springframework.context.annotation.*;
import tw.com.softleader.data.config.DatabaseDefinition;
import tw.com.softleader.data.config.EnableCoreDataSource;
import tw.com.softleader.data.entity.EntityPersistenceCallbackSupplier;
import tw.com.softleader.domain.annotatioin.EnableCoreDomain;
import tw.com.softleader.security.supplier.CurrentUsernameSupplier;

@EnableAspectJAutoProxy(proxyTargetClass = true)
@ComponentScan(basePackages = "{pkg}.**.service")
@EnableCoreDataSource(
  database = DatabaseDefinition.{database},
  idStrategies = {"{pkg}.**=AUTO", "tw.com.softleader.**=AUTO"},
  entityPackagesToScan = "{pkg}.**.entity",
  mapperBasePackages = "{pkg}.**.dao",
  propertySources = "datasource.properties"
)
@EnableCoreDomain
@Configuration
public class ApplicationConfig {

  @Bean
  public CurrentUsernameSupplier currentUsernameSupplier() {
    return new CurrentUsernameSupplier();
  }

  @Bean
  @Primary
  public EntityPersistenceCallbackSupplier entityPersistenceCallbackSupplier() {
    return new EntityPersistenceCallbackSupplier(currentUsernameSupplier());
  }
}
