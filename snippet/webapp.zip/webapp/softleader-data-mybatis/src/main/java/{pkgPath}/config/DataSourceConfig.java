package {pkg}.config;

import com.google.common.collect.Lists;
import org.mybatis.spring.mapper.MapperScannerConfigurer;
import org.springframework.beans.BeansException;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;
import org.springframework.stereotype.Repository;
import tw.com.softleader.data.config.DataSourceConfiguration;
import tw.com.softleader.data.entity.EntityPersistenceCallbackSupplier;
import tw.com.softleader.security.supplier.CurrentUsernameSupplier;

import java.util.Collection;

/**
 * @see https://github.com/softleader/softleader-framework-docs/wiki/Mybatis-Datasource-Setup
 */
@Configuration
@Import(DataSourceConfiguration.class)
public class DataSourceConfig implements ApplicationContextAware {

  private ApplicationContext applicationContext;

  @Bean
  public Collection<String> entityPackagesToScan() {
    return Lists.newArrayList("{pkg}.demo.entity");
  }

  @Bean
  public EntityPersistenceCallbackSupplier entityPersistenceSupport() {
    final CurrentUsernameSupplier userSupplier = applicationContext.getBean(CurrentUsernameSupplier.class);
    return new EntityPersistenceCallbackSupplier(userSupplier);
  }

  @Bean
  public MapperScannerConfigurer mapperScannerConfigurer() {
    final MapperScannerConfigurer mapperScanner = new MapperScannerConfigurer();
    mapperScanner.setBasePackage("{pkg}.**.dao");
    mapperScanner.setAnnotationClass(Repository.class);
    mapperScanner.setSqlSessionFactoryBeanName("sqlSessionFactory");
    return mapperScanner;
  }

  @Override
  public void setApplicationContext(ApplicationContext applicationContext) throws BeansException {
    this.applicationContext = applicationContext;
  }

}
